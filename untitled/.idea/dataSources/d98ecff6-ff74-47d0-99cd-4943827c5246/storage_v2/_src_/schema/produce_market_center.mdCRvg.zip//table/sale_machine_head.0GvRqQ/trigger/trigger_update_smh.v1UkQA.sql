create definer = root@`%` trigger Trigger_update_smh
    after update
    on sale_machine_head
    for each row
BEGIN
  DECLARE modify_remark varchar(999) ;
  DECLARE modify_remark_temp varchar(255) ;
  DECLARE modify_temp varchar(255) ;
  DECLARE s_old_date varchar(10) ;
  DECLARE s_new_date varchar(10) ;
  DECLARE s_old_status varchar(50) ;
  DECLARE s_new_status varchar(50) ;
  DECLARE machine_no varchar(50) ;
 
  DECLARE i int(2);
  DECLARE hisid int(11);
 
  set @modify_remark_temp='本次修改了以下内容：';
  set @machine_no=new.machine_number;
  set @i=0;
  if new.machine_number <> old.machine_number  then
	 set @modify_temp=concat('机台编写：',+old.machine_number,' -> ',new.machine_number,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if new.product_number <> old.product_number  then
	 set @modify_temp=concat('产品：',old.product_name,' -> ',new.product_name,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if new.sales_nickname <> old.sales_nickname  then
	 set @modify_temp=concat('销售负责人：',old.sales_nickname,' -> ',new.sales_nickname,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
 if new.customerid <> old.customerid  then
	 set @modify_temp=concat('客户：',old.customername,' -> ',new.customername,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if new.remarks <> old.remarks  then
	 set @modify_temp=concat('备注：',old.remarks,' -> ',new.remarks,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if new.product_out_saledate <> old.product_out_saledate  then
  	 INSERT INTO sale_machine_head_his_date(machine_number,modify_type,old_date,new_date) 
  	 VALUES(@machine_no,'0',old.product_out_saledate,new.product_out_saledate); 
     set @s_old_date = (select date_format(old_date,'%Y-%m-%d') from sale_machine_head_his_date where machine_number=@machine_no and modify_type='0');
     set @s_new_date = (select date_format(new_date,'%Y-%m-%d') from sale_machine_head_his_date where machine_number=@machine_no and modify_type='0');

	 set @modify_temp=concat('预计出货日期：',@s_old_date,' -> ',@s_new_date,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if new.production_status <> old.production_status  then
     if new.production_status = 0 then
     	set @s_old_status = '已出货';
     end if;
     if new.production_status = 1 then
     	set @s_new_status = '待出货';
     end if;
     if new.production_status = 2 then
     	set @s_new_status = '生产中';
     end if;
     if old.production_status = 0 then
     	set @s_old_status = '已出货';
     end if;
     if old.production_status = 1 then
     	set @s_old_status = '待出货';
     end if;
     if old.production_status = 2 then
     	set @s_old_status = '生产中';
     end if;
	 set @modify_temp=concat('生产状态：',@s_new_status,' -> ',@s_old_status,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if new.production_complete_time <> old.production_complete_time  then
  	 INSERT INTO sale_machine_head_his_date(machine_number,modify_type,old_date,new_date) 
  	 VALUES(@machine_no,'1',old.production_complete_time,new.production_complete_time);
  	 set @s_old_date = (select date_format(old_date,'%Y-%m-%d') from sale_machine_head_his_date where machine_number=@machine_no and modify_type='1');
     set @s_new_date = (select date_format(new_date,'%Y-%m-%d') from sale_machine_head_his_date where machine_number=@machine_no and modify_type='1');
   
	 set @modify_temp=concat('生产完成日期：',@s_old_date,' -> ',@s_new_date,'；');
	 set @modify_remark_temp=concat(@modify_remark_temp,@modify_temp);
	 set @i=@i+1;
  end if;
  if @i>0 then
     
  	if new.machine_number <> old.machine_number or new.product_number <> old.product_number or new.sales_nickname <> old.sales_nickname or new.remarks <> old.remarks or new.product_out_saledate <> old.product_out_saledate or new.production_status<>old.production_status or new.production_complete_time <> old.production_complete_time or new.customerid <> old.customerid then
 	     INSERT INTO sale_machine_head_his
    	 (ticket_id, headid, machine_number, product_number, product_name, product_type, manager, customerid, customername, product_out_saledate, sales_username, sales_nickname, production_status, production_complete_time, remarks, modify_remarks, update_time, update_by, machine_sort)
     	 VALUES('',new.id,new.machine_number, new.product_number, new.product_name, new.product_type, new.manager, null,'',new.product_out_saledate,new.sales_username,new.sales_nickname, new.production_status,new.production_complete_time,new.remarks,@modify_remark_temp, new.update_time, new.update_by,new.machine_sort); 			  
	end if;
    delete from sale_machine_head_his_date where machine_number=@machine_no ;
  end if;
END;

